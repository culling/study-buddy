module.exports = {
  // "globDirectory": "public/",
  // "globPatterns": [
    // "**/*.{json,js,md,yml,sh,css,lock,html,nuspec,ps1,scss,svg,png,xml,ico,txt,jsx,mp3}"
  // ],
  // "swDest": "public/sw.js",
};